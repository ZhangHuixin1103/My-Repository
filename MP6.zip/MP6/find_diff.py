#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
Command:
python find_diff.py -f1 aaa.pdb -f2 bbb.pdb

./DESRES-Trajectory_pnas2011a-C-0-no-water-no-lipid/pnas2011a-C-0-no-water-no-lipid/pnas2011a-C-0-no-water-no-lipid-vmd.pdb
'''

'''
1. difflib的HtmlDiff类创建html表格用来展示文件差异
2. make_file：
    make_file(fromlines, tolines [, fromdesc][, todesc][, context][, numlines])
    生成一个包含表格的html文件，用来展示差异
    fromlines和tolines，用于比较的内容，格式为字符串组成的列表
    fromdesc和todesc，可选参数，对应的fromlines, tolines的差异化文件的标题，默认为空字符串
    context和numlines，可选参数，context=True时，只显示差异的上下文，默认显示numlines=5行；
    context=False时，差异部分颜色高亮，默认为显示全文
3. 使用argparse传入两个需要对比的文件
'''

import difflib
import argparse
import sys


# 创建打开文件函数，并按换行符分割内容
def readfile(filename):
    try:
        with open(filename, 'r') as fileHandle:
            text = fileHandle.read().splitlines()
        return text
    except IOError as e:
        print("Read file Error:", e)
        sys.exit()


# 比较两个文件并输出到html文件中
def diff_file(filename1, filename2):
    text1_lines = readfile(filename1)
    text2_lines = readfile(filename2)
    d = difflib.HtmlDiff()
    result = d.make_file(text1_lines, text2_lines,
                         filename1, filename2, context=True)
    # 内容保存到result.html文件中
    with open('./result.html', 'w') as resultfile:
        resultfile.write(result)
    # print(result)


if __name__ == '__main__':
    # 传入两个参数，格式-f1 filename1 -f2 filename
    parser = argparse.ArgumentParser(description="传入两个文件参数")
    parser.add_argument('-f1', action='store', dest='filename1', required=True)
    parser.add_argument('-f2', action='store', dest='filename2', required=True)
    given_args = parser.parse_args()
    filename1 = given_args.filename1
    filename2 = given_args.filename2
    diff_file(filename1, filename2)
