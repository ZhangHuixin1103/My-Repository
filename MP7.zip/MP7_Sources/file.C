/*
    File       : file.C

    Author     : Riccardo Bettati
    Modified   : 2021/11/28

    Description: Implementation of simple File class, with support for
                 sequential read/write operations.
*/

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

/* -- (none) -- */

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "assert.H"
#include "console.H"
#include "file.H"

/*--------------------------------------------------------------------------*/
/* CONSTRUCTOR/DESTRUCTOR */
/*--------------------------------------------------------------------------*/

File::File(FileSystem *_fs, int _id)
{
    Console::puts("Opening file.\n");

    fs = _fs;
    id = _id;

    inode = fs->LookupFile(_id);
    curr_pos = 0;

    // Fetch data for this file
    fs->BlockDisk(DISK_OPERATION::READ, inode->block_id, block_cache);
}

File::~File()
{
    Console::puts("Closing file.\n");

    /* Make sure that you write any cached data to disk. */
    /* Also make sure that the inode in the inode list is updated. */

    fs->BlockDisk(DISK_OPERATION::WRITE, inode->block_id, block_cache);
    inode->inode_disk(DISK_OPERATION::WRITE);
}

/*--------------------------------------------------------------------------*/
/* FILE FUNCTIONS */
/*--------------------------------------------------------------------------*/

/* !!! THIS PART IS WITH HELP FROM ONLINE SOURCE: !!!
   https://github.com/rajendra-sahu/CSCE611-MPs/blob/master/mp7/design.pdf */

int File::Read(unsigned int _n, char *_buf)
{
    Console::puts("reading from file\n");

    unsigned int read_num = 0;
    bool EoF_limited;

    while ((read_num <= _n) && ((EoF_limited = EoF()) == false))
    {
        _buf[read_num] = block_cache[curr_pos];
        read_num++;
        curr_pos++;
    }

    if (EoF_limited)
        Reset();

    if (curr_pos != 0)
        return read_num - 1;
    else
        return read_num;
}

int File::Write(unsigned int _n, const char *_buf)
{
    Console::puts("writing to file\n");

    if (_n > SimpleDisk::BLOCK_SIZE)
        _n = SimpleDisk::BLOCK_SIZE;

    unsigned int write_num = 0;

    while (write_num <= _n)
    {
        if (EoF())
            Reset();

        block_cache[curr_pos] = _buf[write_num];
        write_num++;
        curr_pos++;
    }

    inode->size = inode->size + write_num;

    return write_num - 1;
}

void File::Reset()
{
    Console::puts("resetting file\n");

    curr_pos = 0;
}

bool File::EoF()
{
    Console::puts("checking for EoF\n");

    if (curr_pos != SimpleDisk::BLOCK_SIZE)
        return false;
    else
        return true;
}

