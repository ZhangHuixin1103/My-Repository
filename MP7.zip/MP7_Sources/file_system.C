/*
    File       : file_system.C

    Author     : Riccardo Bettati
    Modified   : 2021/11/28

    Description: Implementation of simple File System class.
                 Has support for numerical file identifiers.
*/

/*--------------------------------------------------------------------------*/
/* DEFINES */
/*--------------------------------------------------------------------------*/

/*--------*/

/*--------------------------------------------------------------------------*/
/* INCLUDES */
/*--------------------------------------------------------------------------*/

#include "assert.H"
#include "console.H"
#include "file_system.H"

/*--------------------------------------------------------------------------*/
/* CLASS Inode */
/*--------------------------------------------------------------------------*/

/* You may need to add a few functions, for example to help read and store
   inodes from and to disk. */

void Inode::inode_disk(DISK_OPERATION _op)
{
    /* FileSystem Disk Address: fs->disk */

    if (_op == DISK_OPERATION::READ)
        fs->disk->read(0, (unsigned char *)(fs->inodes));
    else
        fs->disk->write(0, (unsigned char *)(fs->inodes));
}

/*--------------------------------------------------------------------------*/
/* CLASS FileSystem */
/*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/
/* CONSTRUCTOR */
/*--------------------------------------------------------------------------*/

FileSystem::FileSystem()
{
    Console::puts("In file system constructor.\n");

    inodes = (Inode *)new unsigned char[512]; // Allocate block for inode list
    freelists = new unsigned char[512];       // Allocate block for free list
}

FileSystem::~FileSystem()
{
    Console::puts("unmounting file system\n");

    /* Make sure that the inode list and the free list are saved. */

    BlockDisk(DISK_OPERATION::WRITE, 0, (unsigned char *)(inodes));
    BlockDisk(DISK_OPERATION::WRITE, 1, freelists);

    delete[] inodes;
    delete[] freelists;
}

/*--------------------------------------------------------------------------*/
/* FILE SYSTEM FUNCTIONS */
/*--------------------------------------------------------------------------*/

bool FileSystem::Mount(SimpleDisk *_disk)
{
    Console::puts("mounting file system from disk\n");

    /* Here you read the inode list and the free list into memory */

    disk = _disk;

    BlockDisk(DISK_OPERATION::READ, 0, (unsigned char *)(inodes));
    BlockDisk(DISK_OPERATION::READ, 1, freelists);

    if (freelists[0] == 1 && freelists[1] == 1) // first two blocks occupied
        return true;
    else
        return false;
}

bool FileSystem::Format(SimpleDisk *_disk, unsigned int _size)
{
    Console::puts("formatting disk\n");

    /* Here you populate the disk with an initialized (probably empty) inode list
       and a free list. Make sure that blocks used for the inodes and for the free list
       are marked as used, otherwise they may get overwritten. */

    unsigned char buf[512];
    for (unsigned int i = 0; i < 512; i++)
    {
        buf[i] = 0xFF;
    }
    _disk->write(0, buf);

    for (unsigned int i = 0; i < 512; i++)
    {
        buf[i] = 0x00;
    }
    buf[0] = 0x01;
    buf[1] = 0x01;
    _disk->write(1, buf);

    return true;
}

Inode *FileSystem::LookupFile(int _file_id)
{
    Console::puts("looking up file with id = ");
    Console::puti(_file_id);
    Console::puts("\n");

    /* Here you go through the inode list to find the file. */

    for (unsigned int i = 0; i < MAX_INODES; i++)
    {
        if (inodes[i].id == _file_id)
            return &inodes[i];
    }
    return NULL;
}

bool FileSystem::CreateFile(int _file_id)
{
    Console::puts("creating file with id:");
    Console::puti(_file_id);
    Console::puts("\n");

    /* Here you check if the file exists already. If so, throw an error.
       Then get yourself a free inode and initialize all the data needed for the
       new file. After this function there will be a new file on disk. */

    if (LookupFile(_file_id))
    {
        Console::puts("File exists already");
        return false;
    }

    unsigned long block_id = GetFreeBlock();
    if (block_id == 0xFFFFFFFF)
    {
        Console::puts("No free block");
        return false;
    }
    unsigned long inode_idx = GetFreeInode();
    if (block_id == 0xFFFFFFFF)
    {
        Console::puts("No free inode");
        return false;
    }

    freelists[block_id] = 1;

    inodes[inode_idx].id = _file_id;
    inodes[inode_idx].block_id = block_id;
    inodes[inode_idx].size = 0;
    inodes[inode_idx].fs = this;

    BlockDisk(DISK_OPERATION::WRITE, 0, (unsigned char *)(inodes));
    BlockDisk(DISK_OPERATION::WRITE, 1, freelists);

    return true;
}

bool FileSystem::DeleteFile(int _file_id)
{
    Console::puts("deleting file with id:");
    Console::puti(_file_id);
    Console::puts("\n");

    /* First, check if the file exists. If not, throw an error.
       Then free all blocks that belong to the file and delete/invalidate
       (depending on your implementation of the inode list) the inode. */

    Inode *node = new Inode();

    if (!(node = LookupFile(_file_id)))
    {
        Console::puts("File doesn't exist");
        return false;
    }

    freelists[node->block_id] = 0;

    node->id = 0xFFFFFFFF;
    node->block_id = 0xFFFFFFFF;
    node->size = 0xFFFFFFFF;

    BlockDisk(DISK_OPERATION::WRITE, 0, (unsigned char *)(inodes));
    BlockDisk(DISK_OPERATION::WRITE, 1, freelists);

    delete node;

    return true;
}

bool FileSystem::BlockDisk(DISK_OPERATION _op, unsigned long _block_id, unsigned char *_buf)
{
    if (_op == DISK_OPERATION::READ)
        disk->read(_block_id, _buf);
    else
        disk->write(_block_id, _buf);

    return true;
}

unsigned long FileSystem::GetFreeBlock()
{
    /* Go through free list, check free block */

    for (unsigned int i = 0; i < 512; i++)
    {
        if (freelists[i] == 0)
        {
            return i;
        }
    }
    return 0xFFFFFFFF;
}

unsigned long FileSystem::GetFreeInode()
{
    /* Go through inode list, check free inode */

    for (unsigned int i = 0; i < MAX_INODES; i++)
    {
        if (inodes[i].id == 0xFFFFFFFF)
        {
            return i;
        }
    }
    return 0xFFFFFFFF;
}

